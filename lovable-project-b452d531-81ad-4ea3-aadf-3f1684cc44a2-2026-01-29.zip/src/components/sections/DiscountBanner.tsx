import { ArrowRight, Clock, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';

const DiscountBanner = () => {
  return (
    <section className="py-12 md:py-16">
      <div className="container-main">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-foreground via-foreground to-foreground/95">
          {/* Subtle pattern */}
          <div className="absolute inset-0 opacity-5">
            <div className="absolute top-0 right-0 w-96 h-96 bg-primary rounded-full blur-3xl translate-x-1/2 -translate-y-1/2"></div>
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent rounded-full blur-3xl -translate-x-1/2 translate-y-1/2"></div>
          </div>

          <div className="relative grid md:grid-cols-2 gap-8 items-center p-8 md:p-12 lg:p-16">
            {/* Content */}
            <div className="text-center md:text-left">
              <div className="inline-flex items-center gap-2 bg-primary/20 text-primary px-4 py-2 rounded-full text-sm font-medium mb-5">
                <Gift className="h-4 w-4" />
                Limited Time Offer
              </div>
              <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl font-semibold text-background mb-4 leading-tight">
                Festive Special
                <br />
                <span className="text-primary">30% OFF</span> Combos
              </h2>
              <p className="text-background/60 text-base md:text-lg mb-8 max-w-md">
                Celebrate with our exclusive festive combo packs. Perfect for gifting or stocking up.
              </p>

              {/* Countdown */}
              <div className="flex items-center gap-3 mb-8 justify-center md:justify-start flex-wrap">
                <div className="flex items-center gap-2 text-background/60">
                  <Clock className="h-4 w-4" />
                  <span className="text-sm font-medium">Ends in:</span>
                </div>
                <div className="flex gap-2">
                  {[
                    { value: '02', label: 'D' },
                    { value: '14', label: 'H' },
                    { value: '32', label: 'M' },
                    { value: '45', label: 'S' }
                  ].map((item, index) => (
                    <div key={index} className="bg-background/10 backdrop-blur-sm rounded-xl px-3 py-2.5 text-center min-w-[52px]">
                      <p className="font-semibold text-lg text-background leading-none mb-0.5">{item.value}</p>
                      <p className="text-[10px] text-background/50 uppercase">{item.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 justify-center md:justify-start">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-8 font-medium shadow-lg shadow-primary/25">
                  Shop Combos
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button size="lg" variant="outline" className="border-background/20 text-background hover:bg-background/10 rounded-full px-6 font-medium">
                  Code: FESTIVE30
                </Button>
              </div>
            </div>

            {/* Image side */}
            <div className="relative hidden md:flex justify-center items-center">
              <div className="relative">
                <div className="relative w-72 h-72 lg:w-80 lg:h-80 rounded-3xl overflow-hidden border border-background/10 shadow-2xl">
                  <img
                    src="https://images.unsplash.com/photo-1549465220-1a8b9238cd48?q=80&w=600"
                    alt="Festive Pickle Combo"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-foreground/30 to-transparent"></div>
                </div>

                {/* Price tag */}
                <div className="absolute -bottom-4 -right-4 bg-primary text-primary-foreground px-5 py-3 rounded-2xl shadow-lg">
                  <p className="text-xs line-through opacity-70">AED 150</p>
                  <p className="font-semibold text-xl">AED 105</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DiscountBanner;
