import { Award, Users, Leaf, Heart, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const AboutUs = () => {
  const highlights = [
    { icon: Leaf, title: '100% Natural', description: 'No preservatives or artificial colors' },
    { icon: Award, title: 'Premium Quality', description: 'Hand-picked from trusted farms' },
    { icon: Users, title: 'Family Recipes', description: 'Three generations of tradition' },
    { icon: Heart, title: 'Made with Love', description: 'Crafted with care in every jar' }
  ];

  return (
    <section id="about" className="section-padding">
      <div className="container-main">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image side */}
          <div className="relative order-2 lg:order-1">
            <div className="relative">
              {/* Main image */}
              <div className="relative rounded-3xl overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?q=80&w=800"
                  alt="Traditional pickle making"
                  className="w-full aspect-[4/3] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/20 to-transparent"></div>
              </div>

              {/* Stats card */}
              <div className="absolute -bottom-6 -right-6 bg-card rounded-2xl p-5 shadow-elevated border border-border/50 hidden md:block">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center">
                    <span className="text-2xl font-serif font-semibold text-primary">25+</span>
                  </div>
                  <div>
                    <p className="font-semibold text-foreground text-sm">Years of Tradition</p>
                    <p className="text-xs text-muted-foreground">Crafting authentic flavors</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Content side */}
          <div className="order-1 lg:order-2">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-5">
              Our Story
            </div>
            <h2 className="section-title font-serif mb-5">
              Bringing the <span className="text-primary">Taste of India</span> to Your Table
            </h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed mb-8">
              <p>
                Founded by a family of pickle enthusiasts, Aachar House was born from a simple desire – 
                to share authentic, homemade pickles with the Indian diaspora in the UAE.
              </p>
              <p>
                We believe great pickles are made with patience, premium ingredients, and love. 
                Every jar carries the essence of traditional Indian flavors, crafted to remind you of home.
              </p>
            </div>

            {/* Highlights grid */}
            <div className="grid grid-cols-2 gap-5 mb-8">
              {highlights.map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <item.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground text-sm">{item.title}</h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <Button className="bg-foreground hover:bg-foreground/90 text-background rounded-full px-6 font-medium">
              Learn More About Us
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
