import { Heart, ShoppingCart, Star, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';

const products = [
  {
    id: 1,
    name: 'Rajasthani Mango Pickle',
    price: 35,
    originalPrice: 45,
    image: 'https://images.unsplash.com/photo-1601648764658-cf37e8c89b70?q=80&w=400',
    rating: 4.9,
    reviews: 234,
    badge: 'Best Seller',
    discount: 22,
    isNew: false
  },
  {
    id: 2,
    name: 'Andhra Mixed Pickle',
    price: 42,
    originalPrice: null,
    image: 'https://images.unsplash.com/photo-1567337710282-00832b415979?q=80&w=400',
    rating: 4.8,
    reviews: 189,
    badge: null,
    discount: null,
    isNew: true
  },
  {
    id: 3,
    name: 'Kerala Lime Pickle',
    price: 28,
    originalPrice: 35,
    image: 'https://images.unsplash.com/photo-1590502593747-42a996133562?q=80&w=400',
    rating: 4.7,
    reviews: 156,
    badge: 'Popular',
    discount: 20,
    isNew: false
  },
  {
    id: 4,
    name: 'Punjabi Garlic Pickle',
    price: 32,
    originalPrice: null,
    image: 'https://images.unsplash.com/photo-1615478503562-ec2d8aa0e24e?q=80&w=400',
    rating: 4.9,
    reviews: 312,
    badge: 'Top Rated',
    discount: null,
    isNew: false
  },
  {
    id: 5,
    name: 'Hyderabadi Green Chili',
    price: 38,
    originalPrice: 48,
    image: 'https://images.unsplash.com/photo-1583119022894-919a68a3d0e3?q=80&w=400',
    rating: 4.6,
    reviews: 98,
    badge: null,
    discount: 21,
    isNew: true
  },
  {
    id: 6,
    name: 'Gujarati Sweet Pickle',
    price: 30,
    originalPrice: null,
    image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?q=80&w=400',
    rating: 4.8,
    reviews: 145,
    badge: 'Mild',
    discount: null,
    isNew: false
  },
  {
    id: 7,
    name: 'Amla Pickle Special',
    price: 36,
    originalPrice: 42,
    image: 'https://images.unsplash.com/photo-1606914469633-bd39206ea739?q=80&w=400',
    rating: 4.7,
    reviews: 87,
    badge: null,
    discount: 14,
    isNew: false
  },
  {
    id: 8,
    name: 'Stuffed Red Chili',
    price: 45,
    originalPrice: null,
    image: 'https://images.unsplash.com/photo-1509358271058-acd22cc93898?q=80&w=400',
    rating: 4.9,
    reviews: 203,
    badge: 'Premium',
    discount: null,
    isNew: false
  }
];

const BestSellers = () => {
  return (
    <section className="section-padding bg-secondary/30">
      <div className="container-main">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
          <div>
            <h2 className="section-title font-serif">Best Selling Pickles</h2>
            <p className="section-subtitle mx-0 mt-3">Our customers' favorites that keep them coming back for more</p>
          </div>
          <Button variant="outline" className="self-start md:self-auto border-foreground/20 text-foreground hover:bg-foreground hover:text-background rounded-full px-6 font-medium">
            View All Products
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {products.map((product, index) => (
            <div
              key={product.id}
              className="card-product group"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {/* Image container */}
              <div className="relative overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full aspect-square object-cover group-hover:scale-105 transition-transform duration-700"
                />
                
                {/* Badges */}
                {product.discount && (
                  <span className="badge-discount">-{product.discount}%</span>
                )}
                {product.badge && (
                  <span className="badge-bestseller">{product.badge}</span>
                )}
                {product.isNew && !product.badge && (
                  <span className="absolute top-4 right-4 bg-success text-success-foreground text-xs font-semibold px-3 py-1.5 rounded-full">
                    New
                  </span>
                )}

                {/* Quick actions */}
                <div className="absolute inset-0 bg-foreground/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
                  <button className="w-11 h-11 bg-card rounded-full flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all shadow-lg transform translate-y-4 group-hover:translate-y-0 duration-300">
                    <Heart className="h-4 w-4" />
                  </button>
                  <button className="w-11 h-11 bg-card rounded-full flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all shadow-lg transform translate-y-4 group-hover:translate-y-0 duration-300 delay-75">
                    <Eye className="h-4 w-4" />
                  </button>
                  <button className="w-11 h-11 bg-primary text-primary-foreground rounded-full flex items-center justify-center hover:bg-accent transition-all shadow-lg transform translate-y-4 group-hover:translate-y-0 duration-300 delay-150">
                    <ShoppingCart className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Product info */}
              <div className="p-4 md:p-5">
                {/* Rating */}
                <div className="flex items-center gap-1.5 mb-2">
                  <Star className="h-3.5 w-3.5 fill-spice-gold text-spice-gold" />
                  <span className="text-xs font-semibold text-foreground">{product.rating}</span>
                  <span className="text-xs text-muted-foreground">({product.reviews})</span>
                </div>

                {/* Name */}
                <h3 className="font-medium text-foreground text-sm md:text-base mb-2 group-hover:text-primary transition-colors line-clamp-2 leading-snug">
                  {product.name}
                </h3>

                {/* Price */}
                <div className="flex items-center gap-2 mb-3">
                  <span className="font-semibold text-primary text-lg">AED {product.price}</span>
                  {product.originalPrice && (
                    <span className="text-sm text-muted-foreground line-through">AED {product.originalPrice}</span>
                  )}
                </div>

                {/* Add to cart button */}
                <Button className="w-full bg-foreground/5 text-foreground hover:bg-primary hover:text-primary-foreground rounded-full text-sm font-medium transition-all" size="sm">
                  Add to Cart
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BestSellers;
