import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: 'Neha Kapoor',
    location: 'Dubai, UAE',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200',
    rating: 5,
    text: 'The mango pickle tastes exactly like the one my mother makes back in India. It brought tears to my eyes! Will definitely order again.'
  },
  {
    id: 2,
    name: 'Rajesh Menon',
    location: 'Abu Dhabi, UAE',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200',
    rating: 5,
    text: 'Best pickle I\'ve had in the UAE. The spice level is perfect, and you can taste the freshness in every bite. Highly recommended!'
  },
  {
    id: 3,
    name: 'Priya Sharma',
    location: 'Sharjah, UAE',
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=200',
    rating: 5,
    text: 'Ordered the festive combo pack as Diwali gifts for friends. Everyone loved it! Great packaging and even better taste.'
  }
];

const Testimonials = () => {
  return (
    <section className="section-padding">
      <div className="container-main">
        <div className="text-center mb-12">
          <h2 className="section-title font-serif">What Our Customers Say</h2>
          <p className="section-subtitle">Real reviews from our pickle-loving family</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="bg-card rounded-2xl p-6 md:p-8 border border-border/50 hover:border-primary/20 transition-all duration-500 hover:shadow-card relative"
            >
              {/* Quote icon */}
              <div className="absolute top-6 right-6 w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                <Quote className="h-4 w-4 text-primary" />
              </div>

              {/* Rating */}
              <div className="flex gap-0.5 mb-5">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-spice-gold text-spice-gold" />
                ))}
              </div>

              {/* Text */}
              <p className="text-muted-foreground text-sm leading-relaxed mb-6">
                "{testimonial.text}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4 pt-5 border-t border-border/50">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <p className="font-semibold text-foreground text-sm">{testimonial.name}</p>
                  <p className="text-xs text-muted-foreground">{testimonial.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
