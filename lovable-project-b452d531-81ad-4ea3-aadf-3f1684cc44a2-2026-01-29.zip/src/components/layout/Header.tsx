import { useState } from 'react';
import { Search, User, Heart, ShoppingCart, Menu, X, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const categories = [
    'Mango Pickle',
    'Lime Pickle',
    'Mixed Pickle',
    'Chili Pickle',
    'Garlic Pickle',
    'Special Combos'
  ];

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-md border-b border-border/40">
      {/* Top bar */}
      <div className="bg-foreground text-background py-2.5 px-4">
        <div className="container-main flex items-center justify-center gap-2 text-sm">
          <span className="hidden sm:inline text-background/70">🎉</span>
          <p className="text-center">
            Free Delivery on orders above AED 100 
            <span className="hidden sm:inline"> | </span>
            <span className="sm:hidden"><br /></span>
            Use code <span className="font-semibold text-primary">NAMASTE10</span> for 10% off
          </p>
        </div>
      </div>

      {/* Main header */}
      <div className="container-main">
        <div className="flex items-center justify-between h-18 py-4">
          {/* Mobile menu button */}
          <button
            className="lg:hidden p-2.5 hover:bg-secondary rounded-xl transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>

          {/* Logo */}
          <a href="/" className="flex items-center gap-3 group">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-sm group-hover:shadow-md transition-shadow">
              <span className="text-primary-foreground font-serif font-bold text-xl">A</span>
            </div>
            <div className="hidden sm:block">
              <h1 className="font-serif font-semibold text-xl text-foreground leading-tight tracking-tight">Aachar House</h1>
              <p className="text-xs text-muted-foreground font-medium">Authentic Indian Pickles</p>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            <a href="/" className="text-foreground hover:text-primary transition-colors font-medium text-sm">Home</a>
            <div className="relative group">
              <button className="flex items-center gap-1.5 text-foreground hover:text-primary transition-colors font-medium text-sm py-2">
                Shop <ChevronDown className="h-4 w-4 transition-transform group-hover:rotate-180" />
              </button>
              <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-52 bg-card rounded-xl shadow-elevated border border-border/50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50 overflow-hidden">
                <div className="py-2">
                  {categories.map((cat) => (
                    <a
                      key={cat}
                      href="#"
                      className="block px-4 py-2.5 text-sm text-foreground hover:bg-secondary hover:text-primary transition-colors"
                    >
                      {cat}
                    </a>
                  ))}
                </div>
              </div>
            </div>
            <a href="#about" className="text-foreground hover:text-primary transition-colors font-medium text-sm">About</a>
            <a href="#blog" className="text-foreground hover:text-primary transition-colors font-medium text-sm">Stories</a>
            <a href="#contact" className="text-foreground hover:text-primary transition-colors font-medium text-sm">Contact</a>
          </nav>

          {/* Search bar - Desktop */}
          <div className="hidden md:flex items-center flex-1 max-w-sm mx-8">
            <div className="relative w-full">
              <Input
                type="text"
                placeholder="Search pickles..."
                className="w-full pl-11 pr-4 py-2.5 bg-secondary/50 border-transparent hover:border-border focus:border-primary rounded-xl transition-all"
              />
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
          </div>

          {/* Action icons */}
          <div className="flex items-center gap-1">
            {/* Mobile search toggle */}
            <button
              className="md:hidden p-2.5 hover:bg-secondary rounded-xl transition-colors"
              onClick={() => setIsSearchOpen(!isSearchOpen)}
            >
              <Search className="h-5 w-5" />
            </button>

            <button className="p-2.5 hover:bg-secondary rounded-xl transition-colors relative group">
              <User className="h-5 w-5" />
            </button>

            <button className="p-2.5 hover:bg-secondary rounded-xl transition-colors relative group">
              <Heart className="h-5 w-5" />
              <span className="absolute top-1 right-1 w-4 h-4 bg-accent text-accent-foreground text-[10px] font-bold rounded-full flex items-center justify-center">
                2
              </span>
            </button>

            <button className="p-2.5 hover:bg-secondary rounded-xl transition-colors relative group">
              <ShoppingCart className="h-5 w-5" />
              <span className="absolute top-1 right-1 w-4 h-4 bg-primary text-primary-foreground text-[10px] font-bold rounded-full flex items-center justify-center">
                3
              </span>
            </button>
          </div>
        </div>

        {/* Mobile search bar */}
        {isSearchOpen && (
          <div className="md:hidden pb-4 animate-fade-in">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search pickles..."
                className="w-full pl-11 pr-4 py-2.5 bg-secondary/50 border-transparent rounded-xl"
              />
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
          </div>
        )}
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="lg:hidden bg-card border-t border-border animate-fade-in">
          <nav className="container-main py-6 space-y-1">
            <a href="/" className="block py-3 px-4 text-foreground hover:text-primary hover:bg-secondary rounded-xl transition-all font-medium">
              Home
            </a>
            <div className="py-3 px-4">
              <p className="font-semibold text-foreground mb-3">Shop Categories</p>
              <div className="space-y-1">
                {categories.map((cat) => (
                  <a
                    key={cat}
                    href="#"
                    className="block py-2.5 px-4 text-sm text-muted-foreground hover:text-primary hover:bg-secondary rounded-lg transition-all"
                  >
                    {cat}
                  </a>
                ))}
              </div>
            </div>
            <a href="#about" className="block py-3 px-4 text-foreground hover:text-primary hover:bg-secondary rounded-xl transition-all font-medium">
              About
            </a>
            <a href="#blog" className="block py-3 px-4 text-foreground hover:text-primary hover:bg-secondary rounded-xl transition-all font-medium">
              Stories
            </a>
            <a href="#contact" className="block py-3 px-4 text-foreground hover:text-primary hover:bg-secondary rounded-xl transition-all font-medium">
              Contact
            </a>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
