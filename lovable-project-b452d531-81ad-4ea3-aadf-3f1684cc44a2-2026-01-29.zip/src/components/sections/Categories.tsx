import { ArrowRight } from 'lucide-react';

const categories = [
  {
    id: 1,
    name: 'Mango Pickle',
    image: 'https://images.unsplash.com/photo-1601648764658-cf37e8c89b70?q=80&w=400',
    count: 12,
  },
  {
    id: 2,
    name: 'Lime Pickle',
    image: 'https://images.unsplash.com/photo-1590502593747-42a996133562?q=80&w=400',
    count: 8,
  },
  {
    id: 3,
    name: 'Mixed Pickle',
    image: 'https://images.unsplash.com/photo-1567337710282-00832b415979?q=80&w=400',
    count: 15,
  },
  {
    id: 4,
    name: 'Chili Pickle',
    image: 'https://images.unsplash.com/photo-1583119022894-919a68a3d0e3?q=80&w=400',
    count: 6,
  },
  {
    id: 5,
    name: 'Garlic Pickle',
    image: 'https://images.unsplash.com/photo-1615478503562-ec2d8aa0e24e?q=80&w=400',
    count: 5,
  },
  {
    id: 6,
    name: 'Gift Sets',
    image: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?q=80&w=400',
    count: 10,
  }
];

const Categories = () => {
  return (
    <section className="section-padding">
      <div className="container-main">
        <div className="text-center mb-12">
          <h2 className="section-title font-serif">Shop by Category</h2>
          <p className="section-subtitle">Explore our carefully curated selection of authentic pickles</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-5">
          {categories.map((category, index) => (
            <a
              key={category.id}
              href="#"
              className="group relative block"
              style={{ animationDelay: `${index * 80}ms` }}
            >
              <div className="relative bg-card rounded-2xl p-3 border border-border/50 hover:border-primary/30 transition-all duration-500 hover:-translate-y-1 hover:shadow-hover overflow-hidden">
                {/* Image */}
                <div className="aspect-square rounded-xl overflow-hidden mb-3 bg-secondary">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
                
                {/* Info */}
                <div className="text-center px-1">
                  <h3 className="font-semibold text-foreground text-sm group-hover:text-primary transition-colors">
                    {category.name}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-0.5">{category.count} Items</p>
                </div>

                {/* Hover arrow */}
                <div className="absolute bottom-3 right-3 w-7 h-7 bg-primary text-primary-foreground rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                  <ArrowRight className="h-3.5 w-3.5" />
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;
