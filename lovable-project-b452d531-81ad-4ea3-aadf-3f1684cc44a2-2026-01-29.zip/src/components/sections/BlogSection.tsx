import { ArrowRight, Calendar, User } from 'lucide-react';
import { Button } from '@/components/ui/button';

const blogPosts = [
  {
    id: 1,
    title: 'The Art of Making Perfect Mango Pickle at Home',
    excerpt: 'Learn the traditional techniques our grandmothers used to create the most delicious mango pickles.',
    image: 'https://images.unsplash.com/photo-1601648764658-cf37e8c89b70?q=80&w=600',
    author: 'Priya Sharma',
    date: 'Jan 15, 2024',
    category: 'Recipes'
  },
  {
    id: 2,
    title: '5 Health Benefits of Indian Pickles You Didn\'t Know',
    excerpt: 'Discover how traditional Indian pickles can boost your immunity and improve digestion naturally.',
    image: 'https://images.unsplash.com/photo-1505253716362-afaea1d3d1af?q=80&w=600',
    author: 'Dr. Anita Patel',
    date: 'Jan 10, 2024',
    category: 'Health'
  },
  {
    id: 3,
    title: 'Pairing Pickles: The Ultimate Guide to Meal Combinations',
    excerpt: 'From biryani to parathas, learn how to perfectly pair pickles with your favorite dishes.',
    image: 'https://images.unsplash.com/photo-1567337710282-00832b415979?q=80&w=600',
    author: 'Chef Ravi Kumar',
    date: 'Jan 5, 2024',
    category: 'Food Tips'
  }
];

const BlogSection = () => {
  return (
    <section id="blog" className="section-padding bg-secondary/30">
      <div className="container-main">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
          <div>
            <h2 className="section-title font-serif">From Our Kitchen</h2>
            <p className="section-subtitle mx-0 mt-3">Recipes, tips, and stories about Indian pickles and cuisine</p>
          </div>
          <Button variant="outline" className="self-start md:self-auto border-foreground/20 text-foreground hover:bg-foreground hover:text-background rounded-full px-6 font-medium">
            View All Posts
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {blogPosts.map((post) => (
            <article
              key={post.id}
              className="group bg-card rounded-2xl overflow-hidden border border-border/50 hover:border-primary/20 transition-all duration-500 hover:shadow-card"
            >
              {/* Image */}
              <div className="relative overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full aspect-[16/10] object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <span className="absolute top-4 left-4 bg-foreground text-background text-xs font-medium px-3 py-1.5 rounded-full">
                  {post.category}
                </span>
              </div>

              {/* Content */}
              <div className="p-5 md:p-6">
                {/* Meta */}
                <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                  <div className="flex items-center gap-1.5">
                    <User className="h-3 w-3" />
                    <span>{post.author}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Calendar className="h-3 w-3" />
                    <span>{post.date}</span>
                  </div>
                </div>

                {/* Title */}
                <h3 className="font-serif font-semibold text-lg text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-2 leading-snug">
                  {post.title}
                </h3>

                {/* Excerpt */}
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2 leading-relaxed">
                  {post.excerpt}
                </p>

                {/* Read more */}
                <a
                  href="#"
                  className="inline-flex items-center gap-1.5 text-primary font-medium text-sm group-hover:gap-2.5 transition-all"
                >
                  Read More
                  <ArrowRight className="h-4 w-4" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BlogSection;
