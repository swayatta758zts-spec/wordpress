import { Truck, Shield, RefreshCw, Headphones, Clock, Award } from 'lucide-react';

const usps = [
  {
    icon: Truck,
    title: 'Free Delivery',
    description: 'On orders above AED 100'
  },
  {
    icon: Shield,
    title: 'Quality Assured',
    description: 'HACCP certified kitchen'
  },
  {
    icon: RefreshCw,
    title: 'Easy Returns',
    description: '7-day return policy'
  },
  {
    icon: Clock,
    title: 'Same Day',
    description: 'Order before 2 PM'
  },
  {
    icon: Headphones,
    title: '24/7 Support',
    description: 'Always here to help'
  },
  {
    icon: Award,
    title: 'Fresh Guarantee',
    description: '12+ months shelf life'
  }
];

const USP = () => {
  return (
    <section className="py-12 md:py-16 border-y border-border/50 bg-secondary/20">
      <div className="container-main">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 md:gap-4">
          {usps.map((usp, index) => (
            <div
              key={index}
              className="group text-center"
            >
              <div className="w-14 h-14 mx-auto mb-4 bg-card border border-border/50 group-hover:border-primary/30 group-hover:bg-primary/5 rounded-2xl flex items-center justify-center transition-all duration-300">
                <usp.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground text-sm mb-1">
                {usp.title}
              </h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                {usp.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default USP;
