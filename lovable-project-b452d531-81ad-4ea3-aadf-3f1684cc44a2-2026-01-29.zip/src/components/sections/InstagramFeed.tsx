import { Instagram, Heart } from 'lucide-react';

const instagramPosts = [
  { id: 1, image: 'https://images.unsplash.com/photo-1601648764658-cf37e8c89b70?q=80&w=400', likes: 234 },
  { id: 2, image: 'https://images.unsplash.com/photo-1567337710282-00832b415979?q=80&w=400', likes: 189 },
  { id: 3, image: 'https://images.unsplash.com/photo-1590502593747-42a996133562?q=80&w=400', likes: 156 },
  { id: 4, image: 'https://images.unsplash.com/photo-1556910103-1c02745aae4d?q=80&w=400', likes: 312 },
  { id: 5, image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?q=80&w=400', likes: 98 },
  { id: 6, image: 'https://images.unsplash.com/photo-1615478503562-ec2d8aa0e24e?q=80&w=400', likes: 267 }
];

const InstagramFeed = () => {
  return (
    <section className="section-padding bg-secondary/30">
      <div className="container-main">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-5 py-2.5 rounded-full text-sm font-medium mb-5">
            <Instagram className="h-4 w-4" />
            @aacharhouse.uae
          </div>
          <h2 className="section-title font-serif">Follow Our Journey</h2>
          <p className="section-subtitle">Join our community and get daily inspiration</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 md:gap-4">
          {instagramPosts.map((post) => (
            <a
              key={post.id}
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative aspect-square rounded-2xl overflow-hidden"
            >
              <img
                src={post.image}
                alt={`Instagram post ${post.id}`}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-foreground/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <div className="flex items-center gap-2 text-background">
                  <Heart className="h-5 w-5 fill-background" />
                  <span className="font-semibold">{post.likes}</span>
                </div>
              </div>

              {/* Instagram icon */}
              <div className="absolute top-3 right-3 w-8 h-8 bg-background/90 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <Instagram className="h-4 w-4 text-foreground" />
              </div>
            </a>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-10">
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-foreground text-background px-7 py-3.5 rounded-full font-medium hover:bg-foreground/90 transition-colors"
          >
            <Instagram className="h-5 w-5" />
            Follow Us on Instagram
          </a>
        </div>
      </div>
    </section>
  );
};

export default InstagramFeed;
