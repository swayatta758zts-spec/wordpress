import { ArrowRight, Star, Leaf, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';

const HeroBanner = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-secondary/50 to-background">
      <div className="container-main py-10 md:py-14 lg:py-16">
        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
          {/* Content */}
          <div className="text-center lg:text-left animate-fade-up">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Leaf className="h-4 w-4" />
              100% Natural & Handcrafted
            </div>
            
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-semibold text-foreground leading-[1.1] mb-5 tracking-tight">
              Taste the <span className="text-primary">Tradition</span> of{' '}
              <span className="text-accent">Homemade</span> Pickles
            </h1>
            
            <p className="text-muted-foreground text-lg mb-8 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              Crafted with love using recipes passed down through generations. 
              Experience authentic Indian flavors, delivered fresh to your doorstep.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-8 h-12 text-base font-medium shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all">
                Explore Collection
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="border-2 border-foreground/20 text-foreground hover:bg-foreground hover:text-background rounded-full px-8 h-12 text-base font-medium transition-all">
                Our Story
              </Button>
            </div>
            
            {/* Trust indicators */}
            <div className="flex items-center gap-8 mt-10 justify-center lg:justify-start">
              <div className="text-center">
                <p className="font-serif font-semibold text-3xl text-foreground">5K+</p>
                <p className="text-xs text-muted-foreground mt-0.5">Happy Customers</p>
              </div>
              <div className="w-px h-12 bg-border"></div>
              <div className="text-center">
                <p className="font-serif font-semibold text-3xl text-foreground">100%</p>
                <p className="text-xs text-muted-foreground mt-0.5">Natural</p>
              </div>
              <div className="w-px h-12 bg-border"></div>
              <div className="text-center">
                <div className="flex justify-center gap-0.5 mb-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-spice-gold text-spice-gold" />
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">4.9 Rating</p>
              </div>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative flex justify-center lg:justify-end">
            <div className="relative">
              {/* Subtle decorative elements */}
              <div className="absolute -top-6 -left-6 w-32 h-32 bg-primary/10 rounded-full blur-3xl"></div>
              <div className="absolute -bottom-6 -right-6 w-40 h-40 bg-accent/10 rounded-full blur-3xl"></div>
              
              {/* Main image */}
              <div className="relative w-72 h-72 md:w-96 md:h-96 rounded-3xl overflow-hidden shadow-elevated">
                <img
                  src="https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?q=80&w=800"
                  alt="Traditional Indian Pickle Jars"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/20 to-transparent"></div>
              </div>

              {/* Floating badges */}
              <div className="absolute -top-3 -left-3 bg-card shadow-card rounded-2xl px-4 py-3 animate-float border border-border/50">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-accent/10 rounded-full flex items-center justify-center">
                    <span className="text-base">🌶️</span>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-foreground">Extra Spicy</p>
                    <p className="text-[10px] text-muted-foreground">Fan Favorite</p>
                  </div>
                </div>
              </div>
              
              <div className="absolute -bottom-3 -right-3 bg-card shadow-card rounded-2xl px-4 py-3 animate-float border border-border/50" style={{ animationDelay: '0.5s' }}>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                    <Award className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-foreground">Best Seller</p>
                    <p className="text-[10px] text-muted-foreground">2024 Award</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroBanner;
